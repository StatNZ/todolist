/*
  THIS IS OUR WEBSITE
  
  Here we display our website in all it's glory
*/
$(document).ready(function(e) {

    // global variables
    var deletedTask = null;
    var editableTask = null;
    var ERROR_LOG = console.error.bind(console);
    var URL = 'https://limitless-brushlands-90934.herokuapp.com';
    
    /* Starts fetching all the relevant information from our db */
    reloadList ();

    /*
     When someone clicks on the box it moves it to the 
     completed list, however, we want our server to know
     that this has taken place, so when the page reloads,
     every task will be in it's appropriate place
    */
    $('#todo-list').on('click', '.done', function() {
        var $taskItem = $(this).parent('li');

	 // make appropriate call to server
	$.ajax ({
	    url: URL + '/place_tasks',
	    type: 'PUT',
	    data: JSON.stringify({
		cat: 1,
		item: $taskItem.find('.task').text()
	    }),
	    contentType: "application/json",
	    dataType: "json",
	    
	});

        $taskItem.slideUp(250, function() {
            var $this = $(this);
            $this.detach();
	    
            // remove the edit button from the task
	    $taskItem.find('.editTask').remove();
	    
	    // prepend the task to the completed list
	    $('#completed-list').prepend($this);
            $this.slideDown();
        });        
    });

    /*
      Add an Icon to the button and open a new dialog box
    */
    $('#add-todo').button({ 
        icons: { primary: "ui-icon-circle-plus" } }).click( function() {
            $('#new-todo').dialog('open');
        });


    /* 
       the dialog box for the adding of a new task	
    */
    $('#new-todo').dialog({ modal : true, autoOpen : false,		    
			    buttons: {
				"Add Task" : function () {

				    var taskName = $('#task').val();

				    $('#task').val('');  // clear the text from the input

				    if (taskName === ""){
					return false;
				    }
				    
				    $.ajax ({
					url: URL + '/tasks',
					type: 'POST',
					data: JSON.stringify({
					    cat: 1,
					    item: taskName
					}),
					contentType: "application/json",
					dataType: "json",

				    })
				    addTodoListItems(taskName);

				    $(this).dialog('close');
				    
				},

				// second button
				"Cancel" : function () { $(this).dialog('close'); }
 			    }
			  });
    
    /*
      The dialog box for the deleted item
    */
    $('#delete-todo').dialog({modal : true, autoOpen : false,
			      buttons: {
				  "Delete Task" : function () {

				      // call our server and tell them to delete the task
				      $.ajax ({
					  url: URL + '/delete_tasks',
					  type: 'DELETE',
					  data: JSON.stringify({
					      item: deletedTask.find('.task').text()
					  }),
					  contentType: "application/json",
					  dataType: "json",
					  
				      });

				      // deletes the selected task, which is stored in a global variable
				      deletedTask.effect('puff', function () {
					  deletedTask.remove();
				      });
				      
				      $(this).dialog('close');
				  },

				  // we do not want to cancel the task
				  "Cancel" : function () { $(this).dialog('close');}
			      }
			     });

    /*
      Make a dialog box for the editing of a new task
    */
    $('#edit-task').dialog({modal : true, autoOpen : false,
			    buttons: {
				"Confirm" : function () {
				    var newTaskName = $('#changed-task').val();
				    
				    if (newTaskName === '') {
					return false;
				    }
				    
				    // EDITS OUR CURRENTLY SELECTED DATA
				    $.ajax ({
					url: URL + '/update_tasks',
					type: 'PUT',
					data: JSON.stringify({
					    previous: editableTask.find('.task').text(),
					    current: newTaskName
					}),
					contentType: "application/json",
					dataType: "json",
				    });
				    
				    editableTask.find('.task').text(newTaskName);
				    
				    $(this).dialog('close');
				},
				
				"Cancel" : function () { $(this).dialog('close'); }
			    }
			   });

    /* Allows for the draggin and dropping of tasks in both list if they
     * implement the class sortable */
    $('.sortlist').sortable({
        connectWith : '.sortlist',
        cursor : 'pointer',
        placeholder : 'ui-state-highlight',
        cancel : '.delete,.done',

	/* The function below executes when an item is dragged from one
	   position to the next, once placed it fires */
	receive : function (event, ui) {
	    var task = ui.item.find('.task');
	    var cat = null;

	    /* Determine which category it came from */
	    if (ui.sender.attr('id') == 'completed-list') {
		cat = 2;
		
		// This ensures we can edit the task after its been sorted
		addTodoListItems (task.text(), cat);
	    } else {
		cat = 1;

		addCompletedListItems (task.text(), cat);
	    }
	    
	    // remove the task
	    ui.item.remove ();
	    
	    /* Let the server know of the changes that have occured */
	    $.ajax ({
		url: URL + '/place_tasks',
		type: 'PUT',
		data: JSON.stringify({
		    cat: cat,
		    item: task.text()
		}),
		contentType: "application/json",
		dataType: "json",
	    });
	}
    });

    // opens the dialog box once we click on the + button
    $('.sortlist').on('click','.editTask', function () {
	// this is where our task needs to be ammended
	editableTask = $(this).parent('li');
	$('#edit-task').dialog('open');
	$('#changed-task').val(editableTask.find('.task').text());
    });

    // opens the dialog box once we click on the x button
    $('.sortlist').on('click','.delete', function () {
	deletedTask = 	$(this).parent('li');
	$('#delete-todo').dialog('open');
    });

    
    /****************************
     ****** HELPER METHODS ******
     ****************************/

    /* Loads our lists with the information stored in the db */
    function reloadList () {
	$.ajax ({
	    url: URL + '/all_tasks',
	    type: 'GET',
	
	}).then (addTodoListBeginning, ERROR_LOG);
    }
    
     /* The functions below are helper methods, These are simply used when a task is created
      * or imported via the server. We use them to diferentiate between the certain tasks, and
      * the placement of these tasks. */
    function addTodoListBeginning (task) {
	var i = 0;
	for (i; i<task.length; i++) {

	    if (task[i].cat == 1)
		addTodoListItems(task[i].item, task[i].cat);
	    else
		addCompletedListItems(task[i].item, task[i].cat);
	}
    }

    /* This function allows you to delete all the tasks that are
     * in both the list. It takes them out of the list on the client
     * side and hopes the database reloads them so they user can see
     * that the database has recorded their information correctly.
     * In essence, they can just do this by hitting reload! */
    function deleteAllTasks() {
	var myTodoNode = document.getElementById('todo-list');
	while (myTodoNode.firstChild) {
	    myTodoNode.removeChild(myTodoNode.firstChild);
	}

	var myCompletedNode = document.getElementById('completed-list');
	while (myCompletedNode.firstChild) {
	    myCompletedNode.removeChild(myCompletedNode.firstChild);
	}
	
    }

    function addTodoListItems (taskName, cat) {
	
	var taskHTML = '<li><span class="done">%</span>';
	taskHTML += '<span class="cat"></span>';
	taskHTML += '<span class="delete">x</span>';
	taskHTML += '<span class="task"></span>';
	taskHTML += '<span class="editTask">+</span></li>';
	
	
	
	var $newTask = $(taskHTML);
	$newTask.find('.task').text(taskName);

	$newTask.hide();
	$('#todo-list').prepend($newTask);
	$newTask.show('clip',250).effect('highlight',1000);
    }

    function addCompletedListItems (taskName, cat) {
	var taskHTML = '<li><span class="done">%</span>';
	taskHTML += '<span class="cat"></span>';
	taskHTML += '<span class="delete">x</span>';
	taskHTML += '<span class="task"></span></li>';
	
	
	var $newTask = $(taskHTML);
	$newTask.find('.task').text(taskName);
	
	$newTask.hide();
	$('#completed-list').prepend($newTask);
	$newTask.show('clip',250).effect('highlight',1000);
    }

    /**********************************
    ****** END OF HELPER METHODS ******
    ***********************************/

    

}); // end ready
