/*
  SERVER!!!

  This is our server, here we place things in our database or we 
  get things from our database 
*/

var express = require('express');
var app = express();
var port = process.env.PORT || 8080;
var bodyParser = require ('body-parser');
var path = require ('path');
var connectionString = "postgres://ijqijrbxfflwsy:709ac0bbf558adabb35748651952718c2ea382ac61e65a0057dae20be979dc63@ec2-50-17-236-15.compute-1.amazonaws.com:5432/deebl1igvk2on0";
var TABLE_NAME = 'task_list';
var pg = require('pg');

var client;
//var client = new pg.Client(connectionString);
//client.connect ();

/*
  Our listening function for our server
*/
app.listen(port, function () {
    console.log('Example app listening on Heroku Server');
});

/* link website to clients */
app.use (express.static(path.join(__dirname + '/front')));

app.use (bodyParser.json());
app.use (function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Access-Control-Allow-Headers');
    next();
});

function connectDB () {
    client = new pg.Client(connectionString);
    client.on('drain', client.end.bind(client));  // disconnect client when done
    client.connect ();
}

function disconnectDB () {
    client.end ();
}


/*
  BELOW ARE OUR MAIN FUNCTIONS FOR INTERACTING WITH
  OUR SERVER/DATABASE, SENDING/RECEIVING INFORMATION FROM/TO
  THE CLIENT. THIS IS OUR...

  **********************************
  ******* REST API FUNCTIONS *******    
  **********************************
*/

app.get('/all_tasks', function (req, res) {
    console.log ('Got a GET request\n');

    connectDB ();
    
    // SQL Query > Select Data
    var query = client.query("SELECT * FROM " + TABLE_NAME);
    var results = [];
    
    // Stream results back one row at a time
    query.on('row', function(row) {
	results.push(row);
    });

    // SUCCESS AND ERROR CATCHES
    query.on('error', function (error) {
	console.log (error);
	res.json (400);
    });

    query.on('end', function() {
	res.json (results);
    });

});
	
app.post('/tasks', function (req, res) {    
    console.log ('Got a POST request\n');

    connectDB ();
    
    // contain our information
    var cat = req.body.cat;
    var taskName = req.body.item;
	     
    // place our information into the db
    var query = client.query("INSERT INTO " + TABLE_NAME + "(cat, item) " +
			     "values ($1, $2)", [cat, taskName]);
    
    // SUCCESS AND ERROR CATCHES
    query.on('error', function (error) {
	console.log (error);
	res.json (400);
    });

    query.on('end', function () {
	console.log ('INSERTED ' + taskName);
	res.json (200);
    });   
});
 
app.delete('/delete_tasks', function (req, res) {
    console.log ('Got a DELETE request\n');

    connectDB ();

    var item = req.body.item;

    // HERE WE DELETE THE CURRENT RECORD
    var query = client.query("DELETE FROM " + TABLE_NAME
			     + " WHERE item = $1 ", [item]);

    // SUCCESS AND ERRORS CATCHES
    query.on('error', function (error) {
	console.log ('Gettign an error in DELETE');
	console.log (error); 
	res.json (400);
    });
    
    query.on('end', function () {
	console.log ('Deleted ' + item);
	res.json (200);
    });
});

/* Modify the existing task */
app.put('/update_tasks', function (req, res) {
    console.log ('Got a PUT request\n');

    connectDB ();
    
    // Locals for parsed information
    var old_task_name = req.body.previous;
    var new_task_name = req.body.current;

    // query the database and update the selected item
    var query = client.query("UPDATE " + TABLE_NAME
			     + " SET item = '" + new_task_name
			     + "' WHERE item = '" + old_task_name +"'");

    // SUCCESS AND ERROR CATCHES
    query.on('error', function (error) {
	console.log (error);
	res.json (400);
    });
	     
    query.on('end', function () {
	console.log ('UPDATED ' + old_task_name + ' TO ' + new_task_name);
	res.json (200);
    });
});

/* Place the existing task in the completed list part of the db */
app.put('/place_tasks', function (req, res) {
    console.log ('Got a PUT request\n');

    connectDB ();
    
    var task = req.body.item;
    var cat = req.body.cat

    // all we need to do is update the category
    var query = null;
    if (cat == 1) {
	query = client.query("UPDATE " + TABLE_NAME
			     + " SET cat = 2 WHERE item = '" + task + "'");
    } else {
	console.log ('cat 2');
	query = client.query("UPDATE " + TABLE_NAME
			     + " SET cat = 1 WHERE item = '" + task +"'");
    }
    query.on('error', function (error) {
	console.log (error);
	res.json (400);
    });

    query.on('end', function () {
	console.log ("UPDATED " + task);
	res.json (200);
    });
});

 
 
 
