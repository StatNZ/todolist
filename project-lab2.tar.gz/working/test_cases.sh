#!/bin/sh

# test the POST method of the database
echo 'Placing task in the database...'
curl -H "Content-Type: application/json" -X POST -d '{"cat":"1","item":"task placed"}' https://limitless-brushlands-90934.herokuapp.com/tasks
echo

# test the GET method of the database
echo 'Getting task(s) from database'
curl -H "Content-Type: application/json" -X GET https://limitless-brushlands-90934.herokuapp.com/all_tasks
echo

# update task in the database (currently fails)
echo 'Updating the task in the databse'
curl -H "Content-Type: application/json" -X PUT -d '{"previous":"task placed","current":"updated task"}' https://limitless-brushlands-90934.herokuapp.com/update_tasks
echo

# change category of task
echo 'Changing the category of the task'
curl -H "Content-Type: application/json" -X PUT -d '{"item":"updated task","cat":"1"}' https://limitless-brushlands-90934.herokuapp.com/place_tasks
echo

# delete the task
echo 'Delete the task'
curl -H "Content-Type: application/json" -X DELETE -d '{"item":"updated task"}' https://limitless-brushlands-90934.herokuapp.com/delete_tasks
echo
